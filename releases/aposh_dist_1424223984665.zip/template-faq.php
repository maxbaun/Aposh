<?php
/* Template Name: FAQ Template */
?>
<?php
  require( get_template_directory() . '/template-about.php' );
?>