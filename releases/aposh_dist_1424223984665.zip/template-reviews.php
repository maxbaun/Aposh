<?php
/* Template Name: Reviews Template */
?>
<?php
  require( get_template_directory() . '/template-about.php' );
?>