<div id='lightboxOverlay' class='lightboxOverlay'></div>
<div id='lightbox' class='lightbox'>
    <div class='lb-outerContainer'>
        <div class='lb-container'>
            <div class='lb-closeContainer'><a class='lb-close'>x</a>
            </div><img class='lb-image' src='' />
            <div class='lb-nav'>
                <a class='lb-prev' href=''></a>
                <a class='lb-next' href=''></a>
            </div>
            <div class='lb-loader'>
                <a class='lb-cancel'></a>
            </div>
        </div>
    </div>
    <div class='lb-dataContainer'>
        <div class='lb-data'>
            <div class='lb-details'><span class='lb-caption'></span><span class='lb-number'></span>
            </div>
        </div>
    </div>
</div>