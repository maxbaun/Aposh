        <div class="category-filter">
          <ul>
            <li><a href="#">All</a></li>
            <li><a href="#">Lighting</a></li>
            <li><a href="#">Fabric Decore</a></li>
            <li><a href="#">Special Effects</a></li>
            <li><a href="#">Audio / Visual</a></li>
          </ul>
        </div>
        <?php echo do_shortcode('[section-breaker][/section-breaker]'); ?> 