<?php 
  /* Template Name: Login Template */
?>

<?php
  $contactInfo = false;
  $map = false;
  $weddingWire = true;
  $availability = true;
  $availabilityClass = "grey";  
?>
<?php require( get_template_directory() . '/template-form.php' ); ?>