
       <div id="page-slider" class="carousel slide page-carousel" data-ride="carousel">
          <div class="carousel-inner" role="listbox">
            <div class="item active">
              <div class="row text-center">
                <div class="image-wrapper">
                  <a href="" data-lightbox="lighting"><img src=""/></a>
                </div>
                <div class="image-wrapper">
                  <a href="" data-lightbox="lighting"><img src=""/></a>
                </div>
                <div class="image-wrapper">
                  <a href="<?php themeImage('rewards_knot.jpg'); ?>" data-lightbox="lighting"><img src="<?php themeImage('rewards_knot.jpg'); ?>"/></a>
                </div>                       
              </div>
            </div>
            <div class="item">
              <div class="row text-center">
                <div class="image-wrapper">
                  <a href="<?php themeImage('rewards_knot.jpg'); ?>" data-lightbox="lighting"><img src="<?php themeImage('rewards_knot.jpg'); ?>"/></a>
                </div>
                <div class="image-wrapper">
                  <a href="<?php themeImage('rewards_knot.jpg'); ?>" data-lightbox="lighting"><img src="<?php themeImage('rewards_knot.jpg'); ?>"/></a>
                </div>
                <div class="image-wrapper">
                  <a href="<?php themeImage('rewards_knot.jpg'); ?>" data-lightbox="lighting"><img src="<?php themeImage('rewards_knot.jpg'); ?>"/></a>
                </div>                       
              </div>
            </div>
            <div class="item">
              <div class="row text-center">
                <div class="image-wrapper">
                  <a href="<?php themeImage('rewards_knot.jpg'); ?>" data-lightbox="lighting"><img src="<?php themeImage('rewards_knot.jpg'); ?>"/></a>
                </div>
                <div class="image-wrapper">
                  <a href="<?php themeImage('rewards_knot.jpg'); ?>" data-lightbox="lighting"><img src="<?php themeImage('rewards_knot.jpg'); ?>"/></a>
                </div>
                <div class="image-wrapper">
                  <a href="<?php themeImage('rewards_knot.jpg'); ?>" data-lightbox="lighting"><img src="<?php themeImage('rewards_knot.jpg'); ?>"/></a>
                </div>                       
              </div>
            </div>                                  
          </div> 
          <a class="left carousel-control" href="#page-slider" role="button" data-slide="prev">
            <div></div>
            <span class="sr-only">Previous</span>
          </a>
          <a class="right carousel-control" href="#page-slider" role="button" data-slide="next">
            <div></div>
            <span class="sr-only">Next</span>
          </a>
        </div>