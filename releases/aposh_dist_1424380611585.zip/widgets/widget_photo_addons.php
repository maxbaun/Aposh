<?php

add_action( 'widgets_init', 'register_photo_addon_widget' ); // function to load my widget
 
function register_photo_addon_widget() {
  register_widget( 'Widget_Photo_Addon' );

}                        // function to register my widget
 
class Widget_Photo_Addon extends WP_Widget {
  function __construct() {
    parent::__construct(
      'widget_photo_addon', // Base ID
      __( 'Photo Addon Widget', 'text_domain' ), // Name
      array( 'description' => __( 'Content for the photo addon widget', 'text_domain' ), ) // Args
    );

    // add_action('admin_enqueue_scripts', array($this, 'upload_scripts'));
    // add_action('admin_enqueue_styles', array($this, 'upload_styles'));    
  }
  // public function upload_scripts()
  // {
  //     wp_enqueue_script('media-upload');
  //     wp_enqueue_script('thickbox');
  //     wp_enqueue_script('upload_media_widget', get_template_directory_uri() . '/widgets/upload-media.js', array('jquery'));
  // }

  // /**
  //  * Add the styles for the upload media box
  //  */
  // public function upload_styles()
  // {
  //     wp_enqueue_style('thickbox');
  // }   

  public function widget( $args, $instance ) {
    $text = $instance['text'];
    $imgData = wp_get_attachment_image_src($instance['image'],'full');
    $img = $imgData[0];
    $link = $instance['link'];
    $title = $instance['title'];
    ?>
      <?php echo do_shortcode('[photo-addons class="grey photo-addons" title="Photo Add Ons"]

        [page-section title="RED CARPET TREATMENT" class="photo-addon-section"]Want to feel like a true star on your special night? Add the red carpet experience to your photobooth. You will get the celebrity treatment as you walk down the red carpet to enter the booth.[/page-section]
        [section-breaker][/section-breaker]

        [page-section title="VIDEO/PICTURE SLIDESHOW" class="photo-addon-section"]
        The video and picture slideshow allows you and all your guests to see all the moments captured in your booth as they happen! This can be on a video projector screen or a LCD TV screen depending on what size you prefer. This is just another way to make your wedding or special event unforgettable!
        [/page-section]
        [section-breaker][/section-breaker]

        [page-section title="SCRAPBOOK" class="photo-addon-section"]
        Do you want the ultimate photo album that all of your guests can be apart of? A scrapbook allows all of your guests to put pictures and add comments into a book that will include many special moments from the night. It is a great keepsake that will be able to look back at for years to come.
        [/page-section]

        [/photo-addons]
      ');
      ?>
    <?php
  }
   
  public function update( $new_instance, $old_instance ) {
    $instance = array();
    $instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';
    $instance['image'] = ( ! empty( $new_instance['image'] ) ) ? strip_tags( $new_instance['image'] ) : '';
    $instance['link'] = ( ! empty( $new_instance['link'] ) ) ? strip_tags( $new_instance['link'] ) : '';
    $instance['text'] = ( ! empty( $new_instance['text'] ) ) ? strip_tags( $new_instance['text'] ) : '';

    return $instance;
  }
   
  function form($instance) {
    $title = __('Title');
    if(isset($instance['title']))
    {
        $title = $instance['title'];
    }

    $image = __('Image ID');
    if(isset($instance['image']))
    {
        $image = $instance['image'];
    }

    $link = '';
    if(isset($instance['link']))
    {
        $link = $instance['link'];
    }   
    $text = '';
    if(isset($instance['text']))
    {
        $text = $instance['text'];
    }
    ?>
    <p>
        <label for="<?php echo $this->get_field_name( 'title' ); ?>"><?php _e( 'Title:' ); ?></label>
        <input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
    </p>

    <p>
        <label for="<?php echo $this->get_field_name( 'image' ); ?>"><?php _e( 'Image ID:' ); ?></label>
        <input name="<?php echo $this->get_field_name( 'image' ); ?>" id="<?php echo $this->get_field_id( 'image' ); ?>" class="widefat" type="text" size="36"  value="<?php echo esc_attr($image); ?>" />
        <!-- <input class="upload_image_button button button-primary" type="button" value="Upload Image" /> -->
    </p>  

    <p>
        <label for="<?php echo $this->get_field_name( 'link' ); ?>"><?php _e( 'Link:' ); ?></label>
        <input name="<?php echo $this->get_field_name( 'link' ); ?>" id="<?php echo $this->get_field_id( 'link' ); ?>" class="widefat" type="text" size="36"  value="<?php echo esc_url( $link ); ?>" />
        <!-- <input class="upload_image_button button button-primary" type="button" value="Upload Image" /> -->
    </p>  

    <p>
        <label for="<?php echo $this->get_field_name( 'text' ); ?>"><?php _e( 'Text:' ); ?></label>
        <textarea name="<?php echo $this->get_field_name( 'text' ); ?>" id="<?php echo $this->get_field_id( 'text' ); ?>" class="widefat"   value="" ><?php echo ( $text ); ?></textarea>
    </p>          
    <?php
  }
}

?>