    <div class="container">
      <div class="row pagination-wrapper text-center">
        <div class="col-md-12">
          <div class="container">
            <?php previous_posts_link('Prev'); ?> 
            <?php next_posts_link('Next'); ?> 
          </div>
        </div>
      </div>
    </div>