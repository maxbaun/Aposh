<?php

function codex_custom_init_djs() {
  $labels = array(
    'name'               => 'DJs',
    'singular_name'      => 'DJ',
    'add_new'            => 'Add New',
    'add_new_item'       => 'Add New DJ',
    'edit_item'          => 'Edit DJ',
    'new_item'           => 'New DJ',
    'all_items'          => 'All DJs',
    'view_item'          => 'View DJ',
    'search_items'       => 'Search DJS',
    'not_found'          => 'No DJ found',
    'not_found_in_trash' => 'No DJ found in Trash',
    'parent_item_colon'  => '',
    'menu_name'          => 'DJs'
  );

  $args = array(
    'labels'             => $labels,
    'public'             => true,
    'publicly_queryable' => true,
    'show_ui'            => true,
    'show_in_menu'       => true,
    'query_var'          => true,
    'rewrite'            => array( 'slug' => 'dj' ),
    'capability_type'    => 'page',
    'has_archive'        => true,
    'hierarchical'       => false,
    'menu_position'      => null,
    'supports'           => array( 'title', 'editor', 'author', 'thumbnail', 'excerpt', 'custom-fields',  )
  );

  register_post_type( 'dj', $args );
}


add_action( 'init', 'codex_custom_init_djs' );

add_action( 'add_meta_boxes', 'dj_meta_box' );
function dj_meta_box()
{
	add_meta_box( 'dj-info', 'DJ Info', 'cb_dj_meta', 'dj', 'normal', 'high' );
}

function cb_dj_meta( $post )
{
	$values = get_post_custom( $post->ID );
	$tagline = isset( $values['tagline-val'] ) ? esc_attr( $values['tagline-val'][0] ) : '';

	?>
	<p>
		<label for="tagline-val">Tagline: </label>
		<input type="text" name="tagline-val" id="tagline-val" value="<?php echo $tagline; ?>" style="width:100%;"/>
	</p>

	<?php	
}


add_action( 'save_post', 'dj_info_meta_box_save' );
function dj_info_meta_box_save( $post_id )
{	
	// now we can actually save the data
	$allowed = array( 
		'a' => array( // on allow a tags
			'href' => array() // and those anchords can only have href attribute
		)
	);
	
	// Probably a good idea to make sure your data is set
	if( isset( $_POST['tagline-val'] ) )
		update_post_meta( $post_id, 'tagline-val', wp_kses( $_POST['tagline-val'], $allowed ) );

}

?>