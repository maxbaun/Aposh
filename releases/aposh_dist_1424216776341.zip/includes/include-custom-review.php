<?php

function codex_custom_init_reviews() {
  $labels = array(
    'name'               => 'Reviews',
    'singular_name'      => 'Review',
    'add_new'            => 'Add New',
    'add_new_item'       => 'Add New Review',
    'edit_item'          => 'Edit Review',
    'new_item'           => 'New Review',
    'all_items'          => 'All Reviews',
    'view_item'          => 'View Review',
    'search_items'       => 'Search Reviews',
    'not_found'          => 'No Review found',
    'not_found_in_trash' => 'No Review found in Trash',
    'parent_item_colon'  => '',
    'menu_name'          => 'Reviews'
  );

  $args = array(
    'labels'             => $labels,
    'public'             => true,
    'publicly_queryable' => true,
    'show_ui'            => true,
    'show_in_menu'       => true,
    'query_var'          => true,
    'rewrite'            => array( 'slug' => 'review' ),
    'capability_type'    => 'page',
    'has_archive'        => true,
    'hierarchical'       => false,
    'menu_position'      => null,
    'supports'           => array( 'title', 'editor', 'author', 'thumbnail', 'excerpt', 'custom-fields',  )
  );

  register_post_type( 'review', $args );
}


add_action( 'init', 'codex_custom_init_reviews' );

add_action( 'add_meta_boxes', 'review_meta_box' );
function review_meta_box()
{
	add_meta_box( 'review-link', 'Review', 'cb_review', 'review', 'normal', 'high' );
}

function cb_review( $post )
{
  return;
	$values = get_post_custom( $post->ID );
	$link = isset( $values['review-link-val'] ) ? esc_attr( $values['review-link-val'][0] ) : '';
	$reviewRating = isset( $values['review-rating-val'] ) ? esc_attr( $values['review-rating-val'][0] ) : '';
	$reviewLocation = isset( $values['review-location-val'] ) ? esc_attr( $values['review-location-val'][0] ) : '';
	$reviewDate = isset( $values['review-date-val'] ) ? esc_attr( $values['review-date-val'][0] ) : '';	
	$reviewServices = isset( $values['review-services-val'] ) ? esc_attr( $values['review-services-val'][0] ) : '';	
	?>
	<p>
		<label for="review-link-val">Wedding Wire Link: </label>
		<input type="text" name="review-link-val" id="review-link-val" value="<?php echo $link; ?>" style="width:100%;"/>
	</p>

	<p>
		<label for="review-rating-val">Rating (Ex: 5): </label>
		<input type="text" name="review-rating-val" id="review-rating-val" value="<?php echo $reviewRating; ?>" style="width:100%;"/>
	</p>
	
	<p>
		<label for="review-location-val">Location (Ex: Misselwood): </label>
		<input type="text" name="review-location-val" id="review-location-val" value="<?php echo $reviewLocation; ?>" style="width:100%;"/>
	</p>
	<p>
		<label for="review-date-val">Date (Ex: 9/21/13): </label>
		<input type="text" name="review-date-val" id="review-date-val" value="<?php echo $reviewDate; ?>" style="width:100%;"/>
	</p>		

	<p>
		<label for="review-services-val">Services (Ex: DJ, Photobooth, Uplighting): </label>
		<input type="text" name="review-services-val" id="review-services-val" value="<?php echo $reviewServices; ?>" style="width:100%;"/>
	</p>
	<?php	
}


add_action( 'save_post', 'review_link_meta_box_save' );
function review_link_meta_box_save( $post_id )
{	
	// now we can actually save the data
	$allowed = array( 
		'a' => array( // on allow a tags
			'href' => array() // and those anchords can only have href attribute
		)
	);
	
	// Probably a good idea to make sure your data is set
	if( isset( $_POST['review-link-val'] ) )
		update_post_meta( $post_id, 'review-link-val', wp_kses( $_POST['review-link-val'], $allowed ) );
		
	if( isset( $_POST['review-rating-val'] ) )
		update_post_meta( $post_id, 'review-rating-val', wp_kses( $_POST['review-rating-val'], $allowed ) );	
		
	if( isset( $_POST['review-location-val'] ) )
		update_post_meta( $post_id, 'review-location-val', wp_kses( $_POST['review-location-val'], $allowed ) );
		
	if( isset( $_POST['review-date-val'] ) )
		update_post_meta( $post_id, 'review-date-val', wp_kses( $_POST['review-date-val'], $allowed ) );
		
	if( isset( $_POST['review-services-val'] ) )
		update_post_meta( $post_id, 'review-services-val', wp_kses( $_POST['review-services-val'], $allowed ) );							

}

?>