<?php

function codex_custom_init_vendors() {
  $labels = array(
    'name'               => 'Vendors',
    'singular_name'      => 'Vendor',
    'add_new'            => 'Add New',
    'add_new_item'       => 'Add New Vendor',
    'edit_item'          => 'Edit Vendor',
    'new_item'           => 'New Vendor',
    'all_items'          => 'All Vendors',
    'view_item'          => 'View Vendor',
    'search_items'       => 'Search Vendors',
    'not_found'          => 'No Vendor found',
    'not_found_in_trash' => 'No Vendor found in Trash',
    'parent_item_colon'  => '',
    'menu_name'          => 'Vendors'
  );

  $args = array(
    'labels'             => $labels,
    'public'             => true,
    'publicly_queryable' => true,
    'show_ui'            => true,
    'show_in_menu'       => true,
    'query_var'          => true,
    'rewrite'            => array( 'slug' => 'vendor' ),
    'capability_type'    => 'page',
    'has_archive'        => true,
    'hierarchical'       => false,
    'menu_position'      => null,
    'supports'           => array( 'title', 'editor', 'author', 'thumbnail', 'excerpt', 'custom-fields',  )
  );

  register_post_type( 'vendor', $args );
}


add_action( 'init', 'codex_custom_init_vendors' );

add_action( 'add_meta_boxes', 'vendor_meta_box' );
function vendor_meta_box()
{
	add_meta_box( 'vendor-link', 'Vendor', 'cb_vendor', 'vendor', 'normal', 'high' );
}

function isVenue($postId){
  $t = get_term_by("name", "Wedding Venues","vendor");
  $isVenue = (has_term($t,'vendor', $postId)) ? true : false;  
  return $isVenue;
}

function cb_vendor( $post )
{  

	$values = get_post_custom( $post->ID );
	$link = isset( $values['vendor-link-val'] ) ? esc_attr( $values['vendor-link-val'][0] ) : '';
	$vendorName = isset( $values['vendor-name-val'] ) ? esc_attr( $values['vendor-name-val'][0] ) : '';
	$vendorPhone = isset( $values['vendor-phone-val'] ) ? esc_attr( $values['vendor-phone-val'][0] ) : '';
	$vendorEmail = isset( $values['vendor-email-val'] ) ? esc_attr( $values['vendor-email-val'][0] ) : '';
  if(isset($post) && isVenue($post->ID))
    $vendorVenuePage = isset( $values['vendor-venue-page'] ) ? esc_attr( $values['vendor-venue-page'][0] ) : '';
	
	?>
	<p>
		<label for="vendor-link-val">Vendor Link (Ex: blackthumbstudio.com): </label>
		<input type="text" name="vendor-link-val" id="vendor-link-val" value="<?php echo $link; ?>" style="width:100%;"/>
	</p>
	
	<p>
		<label for="vendor-phone-val">Vendor Phone (Ex: (978) 325-0506): </label>
		<input type="text" name="vendor-phone-val" id="vendor-phone-val" value="<?php echo $vendorPhone; ?>" style="width:100%;"/>
	</p>
	
	<p>
		<label for="vendor-phone-val">Vendor Email (Ex: andy@sussman.com): </label>
		<input type="text" name="vendor-email-val" id="vendor-email-val" value="<?php echo $vendorEmail; ?>" style="width:100%;"/>
	</p>		


  <?php if(isVenue()): ?>
    <?php
      $args = array(
        'post_type' => 'venue',
        'posts_per_page'=> '-1',
        'orderby' => array(
            'title' => 'ASC'
          )
      );
      $venueQuery = new WP_Query($args);
    ?> 
    <p>
      <label for="vendor-venue-page">Venue Page: </label>
      <select name="vendor-venue-page" id="vendor-venue-page">
        <option value=0>None</option>
        <?php while ($venueQuery->have_posts()) : $venueQuery->the_post(); ?>
          <option value="<?php the_permalink(); ?>" <?php if(get_the_permalink() === $vendorVenuePage): ?>selected<?php endif; ?> ><?php the_title(); ?></option>
        <?php endwhile; wp_reset_query();?>    
      </select>
    </p>
  <?php endif; ?>

	<?php	
}


add_action( 'save_post', 'vendor_link_meta_box_save' );
function vendor_link_meta_box_save( $post_id )
{	
	// now we can actually save the data
	$allowed = array( 
		'a' => array( // on allow a tags
			'href' => array() // and those anchords can only have href attribute
		)
	);
	
	// Probably a good idea to make sure your data is set
	if( isset( $_POST['vendor-link-val'] ) )
		update_post_meta( $post_id, 'vendor-link-val', wp_kses( $_POST['vendor-link-val'], $allowed ) );
		
	if( isset( $_POST['vendor-name-val'] ) )
		update_post_meta( $post_id, 'vendor-name-val', wp_kses( $_POST['vendor-name-val'], $allowed ) );	
		
	if( isset( $_POST['vendor-phone-val'] ) )
		update_post_meta( $post_id, 'vendor-phone-val', wp_kses( $_POST['vendor-phone-val'], $allowed ) );
		
	if( isset( $_POST['vendor-email-val'] ) )
		update_post_meta( $post_id, 'vendor-email-val', wp_kses( $_POST['vendor-email-val'], $allowed ) );

  if(isVenue($post_id) && isset( $_POST['vendor-venue-page'] ) )
    update_post_meta( $post_id, 'vendor-venue-page', wp_kses( $_POST['vendor-venue-page'], $allowed ) );  
						

}

function add_vendor_taxonomies() {

	register_taxonomy('vendor', 'vendor', array(
		// Hierarchical taxonomy (like categories)
		'hierarchical' => true,
		// This array of options controls the labels displayed in the WordPress Admin UI
		'labels' => array(
			'name' => _x( 'Vendor Category', 'taxonomy general name' ),
			'singular_name' => _x( 'Vendor-Category', 'taxonomy singular name' ),
			'search_items' =>  __( 'Search Vendor-Categories' ),
			'all_items' => __( 'All Vendor-Categories' ),
			'parent_item' => __( 'Parent Vendor-Category' ),
			'parent_item_colon' => __( 'Parent Vendor-Category:' ),
			'edit_item' => __( 'Edit Vendor-Category' ),
			'update_item' => __( 'Update Vendor-Category' ),
			'add_new_item' => __( 'Add New Vendor-Category' ),
			'new_item_name' => __( 'New Vendor-Category Name' ),
			'menu_name' => __( 'Vendor Categories' ),
		),

		// Control the slugs used for this taxonomy
		'rewrite' => array(
			'slug' => 'vendor', // This controls the base slug that will display before each term
			'with_front' => false, 
			'hierarchical' => true 
		),
	));
}
add_action( 'init', 'add_vendor_taxonomies');

?>