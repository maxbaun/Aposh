<?php 
  
  require_once('include-custom-page-dj.php');
  require_once('include-custom-review.php');
  require_once('include-custom-faq.php');
  require_once('include-custom-vendor.php');
  require_once('include-custom-gallery.php');

?>