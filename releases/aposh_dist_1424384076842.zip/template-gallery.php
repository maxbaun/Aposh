<?php
/* Template Name: Gallery Template */
?>
<?php
  require( get_template_directory() . '/template-about.php' );
?>