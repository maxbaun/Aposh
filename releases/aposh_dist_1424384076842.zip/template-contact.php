<?php 
  /* Template Name: Contact Template */
?>

<?php
  $contactInfo = true;
  $map = true;
  $weddingWire = true;
  $availability = true;
?>
<?php require( get_template_directory() . '/template-form.php' ); ?>